﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Honeywell4600Series
{
    public class Device
    {
    }
}
