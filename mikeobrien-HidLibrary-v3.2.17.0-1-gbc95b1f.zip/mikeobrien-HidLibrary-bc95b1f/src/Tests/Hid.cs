﻿using NUnit.Framework;
using Should;

namespace Tests
{
    [TestFixture]
    public class Hid
    {
        [Test]
        public void Get_Some_Tests_In_Here()
        {
            true.ShouldBeTrue();
        }
    }
}
